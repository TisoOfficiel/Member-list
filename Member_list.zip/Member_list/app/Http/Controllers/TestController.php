<?php

namespace App\Http\Controllers;

use App\Models\Nom;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;



class TestController extends Controller
{
    // Page principal lors de la première ouverture
    public function index(){
        // On recupére toutes les peronnes de la base de donnée sous $personnes
        $personnes=Nom::all();
        // On retourne a la view nom avec la variables réutilisable personnes
        return view('nom',['personnes'=>$personnes]);
    }
    
   
    // Fonction pour ajouter une nouvelle personne
    public function CreationUtilisateur(Request $request){
        
        // Validation des données qui ont été reçut
        $validator = Validator::make($request->all(),[       
            'name'=>['required','alpha_dash'],
            'prenom'=>['required','alpha_dash'],
            'age'=>['required','int']
        ]);

        // Si il y a une erreur 
        if($validator->fails()){
            
            // On renvoie un message flash et on redirige sur la page principal avec les erreurs ainsi que les anciennes valeur entrès dans le formulaire
            $request->session()->flash('echecAjout','Ajout raté');
            return redirect()->route('home')
                    ->withErrors($validator)
                    ->withInput();
                
      }
        // Si il y a pas d'érreur
        // On crée une nouvelle personne dans la base de donnée
        $utilisateur=new Nom();
        // Chaque colonnes de la base de donnée reçoit les valeurs envoyé par le formulaire a l'aide $request
        $utilisateur->nom=$request->name;
        $utilisateur->prenom=$request->prenom;
        $utilisateur->age=$request->age;

        // On sauvegarde la personne et ajoute défénitivement la personne
        $utilisateur->save();
        
        // On retourne sur la page principale avec un message flash de succé
        $request->session()->flash('sucessAjout','Ajout effectué');
        return redirect()->route('home');
        }


    
    // Fonction pour modifier une personne

    public function ModificationUtilisateur(Request $request,$id){
        
       // Validation des données qui ont été reçut
        $validator = Validator::make($request->all(),[       
            'nameNew'=>['required','alpha_dash'],
            'prenomNew'=>['required','alpha_dash'],
            'ageNew'=>['required','int']
        ]);

        // Si il y a une erreur 
        if($validator->fails()){
            // On renvoie un message flash et on redirige sur la page principal avec les erreurs ainsi que les anciennes valeur entrès dans le formulaire et l'id de la personne qu'on modifier
            $request->session()->flash('echecModif','Modification raté');
            
            return redirect()->route('home')
                    ->with('UserId',$id)
                    ->withErrors($validator)
                    ->withInput();
                
      }
         // Si il y a pas d'érreur
        // On récupère l'id de la personne du formulaire et prends la personne correspondant dans la base de donnée
        $utilisateur=Nom::where('id',$id)->first();

        // On modifie chaque valeur par les nouvelles qu'on a reçut
        $utilisateur->nom=$request->nameNew;
        $utilisateur->prenom=$request->prenomNew;
        $utilisateur->age=$request->ageNew;

        // On sauvegarde
        $utilisateur->save();

        //On retourne sur la page principal avec un message flash de succés
        $request->session()->flash('sucessModification','Modification effectué');
        return redirect()->route('home');  

    }


    //Fonction pour supprimer
    public function SuppressionUtilisateur(Request $request,$id){

        // On récupère la personne avec l'id correspondant a celle qu'on veut supprimer
        Nom::where('id',$id)->first()->delete();


        // Puis on retourne sur la page principale avec un message flash de succés
        $request->session()->flash('sucessSuppression','Suppression effectué');
        return redirect()->route('home');
    }

   
}
