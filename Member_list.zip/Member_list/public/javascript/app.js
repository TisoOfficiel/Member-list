function addfunction(id,nom,prenom,age) {
  var form = document.getElementById("form22");
  form.style.display = "block";
  var edit =document.getElementById("edituser");
  edit.style.display = "block";
  var add = document.getElementById("addformulaire");
  add.style.display = "none";

  var width = document.getElementById("tableaContainer");
  width.style.width = "1100px";

    var str = nom
    var str2= prenom
    var str3= age
    document.getElementById('txt').value = str;
    document.getElementById('txt2').value = str2;
    document.getElementById('txt3').value = str3;
    document.getElementById('edisend').action =""+id+"/modification";

}

// Affichage du formulaire et aggrandissage du container
function displayeadd(){
  var form = document.getElementById("form22");
  form.style.display = "block";
  var edit =document.getElementById("edituser");
  edit.style.display = "none";
  var add = document.getElementById("addformulaire");
  add.style.display = "block";

  var width = document.getElementById("list44");
  width.style.width = "1100px";
}


// Function fermer le formulaire
function closemodal() {
  var form = document.getElementById("form22");
  form.style.display = "none";
  var edit =document.getElementById("edituser");
  edit.style.display = "none";
  var add = document.getElementById("addformulaire");
  add.style.display = "none";
  var width = document.getElementById("tableaContainer");
  width.style.width = "590px";

}

// Function pour fermer la notif

function closenotif(statut){
    if(statut=='sucess'){
      document.getElementById("sucessNotif").style.display = "none";
    }
    if(statut=='echec')
    {
      document.getElementById("echecNotif").style.display = "none";
    }
}

// Function pour faire la recherche dans le tableau
function seachkey() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("myInput");
  console.log(document.getElementById("myInput").value);
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}