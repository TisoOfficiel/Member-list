<?php $__env->startSection('title', 'Tableau de noms'); ?>
<?php $__env->startSection('linkcss','/css/main.css'); ?>
<?php $__env->startSection('content'); ?>
<form action="/route" method="POST">
<input type="hidden" name="_method" value="DELETE"> 
<input type="hidden" name="_token" value="the_token">
<button type="submit" class="btn btn-link" onclick="if (!confirm('Are you sure?')) { return false }"><span>Delete</span></button>
<button onclick="(Sondage())">sondage</button>
</form>
<table>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Age</th>
    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($personne-> nom); ?></td>
        <td> <?php echo e($personne->prenom); ?></td>
        <td class="age"> <?php echo e($personne->age); ?></td>
        

        <td><button onclick="ShowFormEditUser(value)" value="<?php echo e($personne->id); ?>">éditer</button></td>
        <td><a href="<?php echo e(route('supprimer',["id"=>$personne->id])); ?>"><i class="material-icons delete">delete</i></a></td>
        <td>
            <div id="<?php echo e($personne->id); ?>" class="test2">
            <form method="POST" action="<?php echo e(route('modifier',["id"=>$personne->id])); ?>">
            <?php echo csrf_field(); ?>
                <input type="text" name="nameNew" value="<?php echo e($personne->nom); ?>">
                <input type="text" name="prenomNew" value="<?php echo e($personne->prenom); ?>">
                <input type="text" name="AgeNew" value="<?php echo e($personne->age); ?>">
                <input type="submit" value="Modifier">
            </form>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>

<button onclick="ShowFormAddUser()" class="btn">Ajouter une personne</button>
<div class="test" id="Element">
    <h4>Ajouter une personnes</h4>
    <form action="/inscriptionvalidation" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="Nom" name="name">
        <input type="text" placeholder="Prenom" name="prenom">
        <input type="text" placeholder="Age" name="age">
        <input type="submit" value="Envoyer">
    </form>
</div>

<div class="test" id="Element2">

</div>



     <!-- <form method="link" action="dualstream/index.html">
<input value = 'apolloz' id="txt" name="stream1" placeholder="" required="required"    
autofocus="autofocus" />
<select id="mySelect" onchange="selectionchange();">
    <option value="abc" data-nom="JEAN">abc</option>
    <option value="xyz" data-nom="PAtrick">xyz</option>
</select>
<input type="submit" class="button" value="Click to watch the stream" />
</form> -->

<div class="container">
<div class="TabUser">
<table>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Age</th>
    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($personne-> nom); ?></td>
        <td> <?php echo e($personne->prenom); ?></td>
        <td class="age"> <?php echo e($personne->age); ?></td>
        

        <td><button onclick="ShowFormEditUser(value)" value="<?php echo e($personne->id); ?>">éditer</button></td>
        <td><a href="<?php echo e(route('supprimer',["id"=>$personne->id])); ?>"><i class="material-icons delete">delete</i></a></td>
        <td>
            <div id="<?php echo e($personne->id); ?>" class="test2">
            <form method="POST" action="<?php echo e(route('modifier',["id"=>$personne->id])); ?>">
            <?php echo csrf_field(); ?>
                <input type="text" name="nameNew" value="<?php echo e($personne->nom); ?>">
                <input type="text" name="prenomNew" value="<?php echo e($personne->prenom); ?>">
                <input type="text" name="AgeNew" value="<?php echo e($personne->age); ?>">
                <input type="submit" value="Modifier">
            </form>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
</div>
<div class="Form">
    <div class="tab">
        <button class="tablinks" onclick="openCity(event, 'add')" id="defaultOpen">Ajouter un personne</button>
        <button class="tablinks" onclick="openCity(event, 'edit')">Modifier une personne</button>
    </div>

    <div id="add" class="tabcontainer">
    <div class="tabcontentadd">
        <h2 class="title">Ajouter une personne</h2>
        <form class="tabcontentform" action="/inscriptionvalidation" method="POST">
            <?php echo csrf_field(); ?>
            <label for="nom">Nom</label>
            <input class="entrer" type="text" id="nom" placeholder="Entrer votre nom" name="name">
            <label for="prenom">Prénom</label>
            <input class="entrer" type="text" id="prenom" placeholder="Entrer votre prénom" name="prenom">
            <label for="age">Age</label>
            <input class="entrer" type="text" id="age" placeholder="Entrer votre age" name="age">
            <input type="submit" class="btn" value="Envoyer">
        </form>
    </div>
    </div>
    <div id="edit" class="tabcontainer">
        <h3>Paris</h3>
        <p>Paris is the capital of France.</p> 
    </div>
    
</div>

</div>

<div class="container2">
  <span class="add">+</span>
  <span class="text">Add new client</span>
</div>
<div class="container2">
  <span class="add">-</span>
  <span class="text">Edit a client</span>
</div>


<div class="test44">
        <div class="bookNow" title='Book Now'>
            <i class="material-icons">add</i>
            <header>Ajouter un utilisateur</header>
        </div>
        
        <div class="bookNow" title='Book Now'>
            
            <i class="material-icons">edit</i>
            <header>Modifier un utilisateur</header>
        </div>
</div>


<div class="listcontainer" id="list44">
    <div class="content44">
    <div class="lishead">
        <h2>Liste d'utilisateur</h2>
        <div class="test44">
            <div class="bookNow" title='Book Now' onclick="test()">
                <i class="material-icons">add</i>
                <header>Ajouter un utilisateur</header>
            </div>
        
            <div class="bookNow" title='Book Now' onclick="test2()">
                <i class="material-icons">edit</i>
                <header>Modifier un utilisateur</header>
            </div>
        </div>
    </div>
    
    <div class="tabletest">
    <table class="tabletest2">
    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="list" ondblclick="myFunction('<?php echo e($personne->id); ?>','<?php echo e($personne->nom); ?>','<?php echo e($personne->prenom); ?>','<?php echo e($personne->age); ?>')">
        <td > <?php echo e($personne-> nom); ?></td>
        <td > <?php echo e($personne->prenom); ?></td>
        <td  class="age"> <?php echo e($personne->age); ?></td>
        <td class="supp"><a onclick="if (!confirm('Êtes-vous sûr de supprimer <?php echo e($personne->nom); ?> <?php echo e($personne->prenom); ?>?')) { return false }" href="<?php echo e(route('supprimer',["id"=>$personne->id])); ?>" ><i class="material-icons delete">delete</i></a></td>                   
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    </table>
    </div>
    </div>
    
    <div class="form22" id="form22">
        <div class="addformulaire" id="addformulaire">
            <h2 class="title">Ajouter une personne</h2>
            <form class="tabcontentform" action="/inscriptionvalidation" method="POST">
                <?php echo csrf_field(); ?>
                <label for="nom">Nom</label>
                <input class="entrer" type="text"  id="nom" placeholder="Entrer votre nom" name="name" value="<?php echo e(old('name')); ?>">
                <label for="prenom">Prénom</label>
                <input class="entrer" type="text"  id="prenom" placeholder="Entrer votre prénom" name="prenom" value="<?php echo e(old('prenom')); ?>">
                <label for="age">Age</label>
                <input class="entrer" type="text"  id="age" placeholder="Entrer votre age" name="age" value="<?php echo e(old('age')); ?>">
                
                <div class="btndiv">
                    <input type="submit" class="btn" value="Envoyer">
                </div>
            </form>
        </div>
                    
        <div class="edituser" id="edituser">
            <h2 class="title">Modifier une personne</h2>
            <form id="edisend"class="tabcontentform" action="" method="POST">
                <?php echo csrf_field(); ?>

                <select id="mySelect" onchange="selectionchange()">
                    <option id="null">Choisir une personne à modifier</option>
                    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option id ="<?php echo e($personne->id); ?>"data-nom=<?php echo e($personne->nom); ?> data-prenom=<?php echo e($personne->prenom); ?> data-age=<?php echo e($personne->age); ?>><?php echo e($personne->nom); ?> <?php echo e($personne->prenom); ?> <?php echo e($personne->age); ?>ans</option>                     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label for="nom">Nom</label>
                <input class="entrer" type="text"  id="txt" placeholder="Entrer votre nom" name="nameNew" value="<?php echo e(old('nameNew')); ?>">
                <label for="prenom">Prénom</label>
                <input class="entrer" type="text"  id="txt2" placeholder="Entrer votre prénom" name="prenomNew" value="<?php echo e(old('prenomNew')); ?>">
                <label for="age">Age</label>
                <input class="entrer" type="text"  id="txt3" placeholder="Entrer votre age" name="ageNew" value="<?php echo e(old('ageNew')); ?>">
                
                
               
                <div class="btndiv">
                    <input type="submit" class="btn" value="Envoyer" id="editbtn" onclick="if (!confirm('Êtes-vous sûr de vouloir modifier cette personne ? ')) { return false }">                                                                      
                </div>
               
            </form>
        </div>
    </div>
</div>

<p id="demo"></p>
<div id="Modal-Container">
        <div id="Modal-Content" class=Modal-Content>

            <!--Tête du modal -->
            <div class="Modal-header">
                <h2>Êtes-vous de vouloir supprimer <?php echo e($personne->nom); ?> <?php echo e($personne->prenom); ?> ?</h2>
                <button class="modal-close" onclick="ModalClose()"><i class="fa fa-times"></i></button>
            </div>

            <!-- Milieu Modal -->
            <div class="Model-body">
                
               <h3>Vous allez supprier <?php echo e($personne->nom); ?> <?php echo e($personne->prenom); ?> êtes-vous de vous ? </h3>
               <h3>En cas de validation il vous sera impossible de revenir en arrière.</h3>
            </div>

            <!-- Footer Modal -->
            <div class="Model-footer1">
                <button onclick="AddSec()" class="bn632-hover bn26" id="AddSec">OUI</button>
            </div>
            <div class="Model-footer2"><button onclick="NotAdd()" class="bn632-hover bn26" id="notAdd">Annuler</button>
            </div>

        </div>
    </div>


    <p class="etat"><?php echo e(session()->get('UserId')); ?></p>
<?php if($errors->any()): ?>

<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="error"><?php echo e($error); ?></div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
<?php endif; ?>
<?php if(session()->has('sucess')): ?>
<p class="etat"><?php echo e(session()->get('sucess')); ?></p>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('linkjavascript',"<?php echo e(URL::asset('/javascript/app.js')); ?>"); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\Exercice3\resources\views/nom.blade.php ENDPATH**/ ?>