<?php $__env->startSection('title', 'Tableau de noms'); ?>
<?php $__env->startSection('linkcss','/css/main.css'); ?>
<?php $__env->startSection('content'); ?>

<section> 
<p class="messagePrevention">Pour éditer vous devez double cliquer normalement c'est intuitif mais au cas ou pour pas perdre de points</p>
<!-- Débutdu container Tableau , formulaire -->


<!-- Si erreur envoie formulaire on aggrandi la card conteneur pour le css -->

<!-- Entête du container -->
    <?php if($errors->any()): ?>
    <div class="listcontainer2" id="tableaContainer">
    <?php else: ?>
    <div class="listcontainer" id="tableaContainer">
    <?php endif; ?>
        <div class="contenttableau">
            <div class="lishead">
                <h2>Liste d'utilisateur</h2>
                <div class="headbutton">
                    <!-- Pour faire une recherche dans le tableau -->
                    <div class="btnAddSeach" >
                        <i class="material-icons">search</i>
                        <input type="text" id="myInput" onkeyup="seachkey()"class="search" placeholder="Nom Rechercher">
                    </div>
                    <!-- Pour afficher le formulaire d'ajout d'une personne -->
                    <div class="btnAddSeach" onclick="displayeadd()">
                        <i class="material-icons">add</i>
                        <header>Ajouter un utilisateur</header>
                    </div>
                
                </div>
            </div>
<!-- Fin entête container -->

<!-- Début tableau -->
            <div class="tabletest">
            <table class="tabletest2" id="myTable">
        
            <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <!-- Double click sur une ligne pour afficher le fomrulaire de modification  -->
                <tr class="list" ondblclick="addfunction('<?php echo e($personne->id); ?>','<?php echo e($personne->nom); ?>','<?php echo e($personne->prenom); ?>','<?php echo e($personne->age); ?>')">
                    <td > <?php echo e($personne-> nom); ?></td>
                    <td > <?php echo e($personne->prenom); ?></td>
                    <td class="age"> <?php echo e($personne->age); ?></td>
                    <td class="supp"><a onclick="if (!confirm('Êtes-vous sûr de supprimer <?php echo e($personne->nom); ?> <?php echo e($personne->prenom); ?>?')) { return false }" href="<?php echo e(route('supprimer',["id"=>$personne->id])); ?>" ><i class="material-icons delete">delete</i></a></td>                   
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </table>
            </div>
        </div>


    <!-- Si erreur envoie formulaire on affiche direct le formulaire dans la card -->
    <?php if($errors->any()): ?>
    <div class="form23" id="form22">
    <?php else: ?>
    <div class="form22" id="form22">
    <?php endif; ?>
        
    <!-- Savoir si on doit afficher le formulaire d'ajout ou non -->
    <?php if(session()->has('echecAjout')): ?>
<!-- Fin tableau -->

<!-- Début Formulaire -->

<!-- Début Formulaire ajout -->
    <div class="addformulaire" id="addformulaire">
    <?php else: ?>
    <div class="addformulaire23" id="addformulaire">
    <?php endif; ?>

            <div class="headeraddform">
                <h2 class="title">Ajouter une personne</h2>
                <div class="close" onclick="closemodal()"><i class="material-icons ">close</i></div>
            </div>
            <form class="tabcontentform" action="/inscriptionvalidation" method="POST">
                <?php echo csrf_field(); ?>
                <label for="nom">Nom</label>
                <input class="entrer" type="text"  id="nom" placeholder="Entrer votre nom" name="name" value="<?php echo e(old('name')); ?>">
                <label for="prenom">Prénom</label>
                <input class="entrer" type="text"  id="prenom" placeholder="Entrer votre prénom" name="prenom" value="<?php echo e(old('prenom')); ?>">
                <label for="age">Age</label>
                <input class="entrer" type="text"  id="age" placeholder="Entrer votre age" name="age" value="<?php echo e(old('age')); ?>">
                
                <div class="btndiv">
                    <input type="submit" class="btn" value="Envoyer">
                </div>
            </form>
    </div>
<!-- Fin Formulaire ajout -->

<!-- Début Formulaire modification -->

    <!-- Savoir si on doit afficher le formulaire de modification ou non -->
    <?php if(session()->has('echecModif')): ?>
        
    <div class="edituser" id="edituser">
    <?php else: ?> 

        <div class="edituser22" id="edituser">
    <?php endif; ?> 
            <div class="headeraddform">
                <h2 class="title">Modifier une personne</h2>
                <div class="close" onclick="closemodal()"><i class="material-icons ">close</i></div>
            </div>
            <?php if($errors->any()): ?>
            <form id="edisend"class="tabcontentform" action="/<?php echo e(session()->get('UserId')); ?>/modification" method="POST"> 
            <?php endif; ?>
            <form id="edisend"class="tabcontentform" action="" method="POST">
                <?php echo csrf_field(); ?>
                <label for="nom">Nom</label>
                <input class="entrer" type="text"  id="txt" placeholder="Entrer votre nom" name="nameNew" value="<?php echo e(old('nameNew')); ?>">
                <label for="prenom">Prénom</label>
                <input class="entrer" type="text"  id="txt2" placeholder="Entrer votre prénom" name="prenomNew" value="<?php echo e(old('prenomNew')); ?>">
                <label for="age">Age</label>
                <input class="entrer" type="text"  id="txt3" placeholder="Entrer votre age" name="ageNew" value="<?php echo e(old('ageNew')); ?>">
            
               
                <div class="btndiv">
                    <input type="submit" class="btn" value="Modifier" id="editbtn" onclick="if (!confirm('Êtes-vous sûr de vouloir modifier cette personne ? ')) { return false }">                                                                      
                </div>
               
            </form>
        </div>
    </div>
</div>

<!-- Fin Formulaire ajout -->

<!-- Fin du container Tableau , formulaire -->


<!-- Début de notifications "message flash"  -->

    <!-- Si il y un ajout ou modif qui se fait alors on affiche la notif sinon non pour le css -->
    <?php if(session()->has('sucessAjout')): ?>
    <div class="notification">
    <?php elseif(session()->has('sucessModification')): ?>
    <div class="notification">
    <?php elseif(session()->has('sucessSuppression')): ?>
    <div class="notification">
    <?php else: ?>
        <div class="notification2">
            <?php endif; ?>
   
        <div id="sucessNotif"class="alert alert-success">
            <span class="icon">
                <i class="material-icons">done</i>
            </span>
        
            <div class="text">
                <!-- Affichage du message d'ajout -->
                <?php if(session()->has('sucessAjout')): ?>
                        <p>Succès <?php echo e(session()->get('sucessAjout')); ?></p>
                        <!-- Affichage du message de modification -->
                <?php elseif(session()->has('sucessModification')): ?>
                        <p>Succès <?php echo e(session()->get('sucessModification')); ?></p>

                        <!-- Affichage du message de suppression -->
                <?php elseif(session()->has('sucessSuppression')): ?>
                        <p>Succès <?php echo e(session()->get('sucessSuppression')); ?></p>
                <?php endif; ?>
                
                
            </div>
        
            <div class="closenotif" onclick="closenotif('sucess')"><i class="material-icons ">close</i></div>
        
        </div>
        </div>


         <?php if(session()->has('echecAjout')): ?>
    <div class="notification">
                <?php elseif(session()->has('echecModif')): ?>
                <div class="notification">
                    <?php else: ?>
                    <div class="notification2">
                <?php endif; ?>
        <div id="echecNotif" class="alert alert-warning">
            <span class="icon">
            <i class="material-icons">priority_high</i>
            </span>
        
            <div class="text">
                <!-- Affichage du message d'echec d'ajout avec errerurs -->
                <?php if(session()->has('echecAjout')): ?>
                        <p>Echec <?php echo e(session()->get('echecAjout')); ?></p>
                        
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                        <?php endif; ?>
                
                        <!-- Affichage du message d'echec de modification avec errerurs -->       
                <?php elseif(session()->has('echecModif')): ?>
                        <p>Echec <?php echo e(session()->get('echecModif')); ?> </p>
                        <?php if($errors->any()): ?>
                        
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                        <?php endif; ?>
                <?php endif; ?>
            </div>
        
            <div class="closenotif" onclick="closenotif('echec')"><i class="material-icons ">close</i></div>
        
        </div>
    </div>
 <!-- Fin de notifications "message flash"  -->
</section>

<?php $__env->startSection('linkjavascript',"<?php echo e(URL::asset('/javascript/app.js')); ?>"); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Bureau\test\rendu\Exercice3\resources\views/nom.blade.php ENDPATH**/ ?>