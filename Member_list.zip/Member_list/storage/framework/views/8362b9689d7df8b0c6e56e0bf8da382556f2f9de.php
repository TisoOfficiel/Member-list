<?php $__env->startSection('title','Test'); ?>
<?php $__env->startSection('link','/css/main.css'); ?>
<?php $__env->startSection('content'); ?>
    <h1 >Bonjour</h1>
    <div class="test"></div>
    <h1>Je suis en dessous de la dive</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romainlhuillier/Desktop/L2/second_semestre/Programation_web/TD/TM2/Exercice3/resources/views/testdiv.blade.php ENDPATH**/ ?>