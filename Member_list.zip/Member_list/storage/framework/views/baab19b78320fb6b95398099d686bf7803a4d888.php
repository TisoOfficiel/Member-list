<?php $__env->startSection('title', 'Tableau de noms'); ?>
<?php $__env->startSection('linkcss','/css/main2.css'); ?>
<?php $__env->startSection('content'); ?>

<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'add')" id="defaultOpen">Ajouter un personne</button>
  <button class="tablinks" onclick="openCity(event, 'edit')">Modifier une personne</button>

</div>

<div id="add" class="tabcontent">
  <h3>Ajuter une personne</h3>
  
  <p>London is the capital city of England.</p>
</div>

<div id="edit" class="tabcontent">
  <h3>Paris</h3>
  <p>Paris is the capital of France.</p> 
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romainlhuillier/Desktop/L2/second_semestre/Programation_web/TD/TM2/Exercice3/resources/views/div.blade.php ENDPATH**/ ?>