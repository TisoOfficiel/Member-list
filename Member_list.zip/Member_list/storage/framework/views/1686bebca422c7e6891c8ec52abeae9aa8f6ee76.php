<?php $__env->startSection('content'); ?>
    
<h4>Vous allez modifier <?php echo e($utilisateur->nom); ?> <?php echo e($utilisateur->prenom); ?></h4>
<form method="POST" action="<?php echo e(route('modifier',["id"=>$utilisateur->id])); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="nameNew">
    <input type="text" name="prenomNew">
    <input type="text" name="AgeNew">
    <input type="submit" value="Modifier">
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romainlhuillier/Desktop/L2/second_semestre/Programation_web/TD/TM2/Exercice3/resources/views/modification.blade.php ENDPATH**/ ?>