<?php $__env->startSection('title', 'Tableau de noms'); ?>
<?php $__env->startSection('linkcss','/css/main.css'); ?>
<?php $__env->startSection('content'); ?>
<table>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Age</th>
    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($personne-> nom); ?></td>
        <td> <?php echo e($personne->prenom); ?></td>
        <td class="age"> <?php echo e($personne->age); ?></td>
        

        <td><button onclick="ShowFormEditUser(value)" value="<?php echo e($personne->id); ?>">éditer</button></td>
        <td><a href="<?php echo e(route('supprimer',["id"=>$personne->id])); ?>"><i class="material-icons delete">delete</i></a></td>
        <td>
            <div id="<?php echo e($personne->id); ?>" class="test2">
            <form method="POST" action="<?php echo e(route('modifier',["id"=>$personne->id])); ?>">
            <?php echo csrf_field(); ?>
                <input type="text" name="nameNew" value="<?php echo e($personne->nom); ?>">
                <input type="text" name="prenomNew" value="<?php echo e($personne->prenom); ?>">
                <input type="text" name="AgeNew" value="<?php echo e($personne->age); ?>">
                <input type="submit" value="Modifier">
            </form>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>

<button onclick="ShowFormAddUser()" class="btn">Ajouter une personne</button>
<div class="test" id="Element">
    <h4>Ajouter une personnes</h4>
    <form action="/inscriptionvalidation" method="POST">
        <?php echo csrf_field(); ?>
        <input type="text" placeholder="Nom" name="name">
        <input type="text" placeholder="Prenom" name="prenom">
        <input type="text" placeholder="Age" name="age">
        <input type="submit" value="Envoyer">
    </form>
</div>

<div class="test" id="Element2">

</div>



     <form method="link" action="dualstream/index.html">
<input value = 'apolloz' id="txt" name="stream1" placeholder="" required="required"    
autofocus="autofocus" />
<select id="mySelect" onchange="selectionchange();">
    <option value="abc" data-nom="JEAN">abc</option>
    <option value="xyz" data-nom="PAtrick">xyz</option>
</select>
<input type="submit" class="button" value="Click to watch the stream" />
</form>

<div class="container">
<div class="TabUser">
<table>
    <th>Nom</th>
    <th>Prénom</th>
    <th>Age</th>
    <?php $__currentLoopData = $personnes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personne): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td> <?php echo e($personne-> nom); ?></td>
        <td> <?php echo e($personne->prenom); ?></td>
        <td class="age"> <?php echo e($personne->age); ?></td>
        

        <td><button onclick="ShowFormEditUser(value)" value="<?php echo e($personne->id); ?>">éditer</button></td>
        <td><a href="<?php echo e(route('supprimer',["id"=>$personne->id])); ?>"><i class="material-icons delete">delete</i></a></td>
        <td>
            <div id="<?php echo e($personne->id); ?>" class="test2">
            <form method="POST" action="<?php echo e(route('modifier',["id"=>$personne->id])); ?>">
            <?php echo csrf_field(); ?>
                <input type="text" name="nameNew" value="<?php echo e($personne->nom); ?>">
                <input type="text" name="prenomNew" value="<?php echo e($personne->prenom); ?>">
                <input type="text" name="AgeNew" value="<?php echo e($personne->age); ?>">
                <input type="submit" value="Modifier">
            </form>
            </div>
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</table>
</div>
<div class="Form">
    <div class="tab">
        <button class="tablinks" onclick="openCity(event, 'add')" id="defaultOpen">Ajouter un personne</button>
        <button class="tablinks" onclick="openCity(event, 'edit')">Modifier une personne</button>
    </div>

    <div id="add" class="tabcontainer">
    <div class="tabcontentadd">
        <h2 class="title">Ajouter une personne</h2>
        <form class="tabcontentform" action="/inscriptionvalidation" method="POST">
            <?php echo csrf_field(); ?>
            <label for="nom">Nom</label>
            <input class="entrer" type="text" id="nom" placeholder="Entrer votre nom" name="name">
            <label for="prenom">Prénom</label>
            <input class="entrer" type="text" id="prenom" placeholder="Entrer votre prénom" name="prenom">
            <label for="age">Age</label>
            <input class="entrer" type="text" id="age" placeholder="Entrer votre age" name="age">
            <input type="submit" class="btn" value="Envoyer">
        </form>
    </div>
    </div>
    <div id="edit" class="tabcontainer">
        <h3>Paris</h3>
        <p>Paris is the capital of France.</p> 
    </div>
    
</div>

</div>

<div class="container2">
  <span class="add">+</span>
  <span class="text">Add new client</span>
</div>
<div class="container2">
  <span class="add">-</span>
  <span class="text">Edit a client</span>
</div>

<div class="test44">
<div class="bookNow" title='Book Now'>
  <h1>X</h1>
  <header>Book An Appointment</header>
</div>

<div class="bookNow" title='Book Now'>
  <h1>X</h1>
  <header>Book An Appointment</header>
</div>
</div>


<?php if($errors->any()): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="error"><?php echo e($error); ?></div> 
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
<?php endif; ?>
<?php if(session()->has('sucess')): ?>
<p class="etat"><?php echo e(session()->get('sucess')); ?></p>

<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('linkjavascript',"<?php echo e(URL::asset('/javascript/app.js')); ?>"); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romainlhuillier/Desktop/L2/second_semestre/Programation_web/TD/TM2/Exercice3/resources/views/nom.blade.php ENDPATH**/ ?>