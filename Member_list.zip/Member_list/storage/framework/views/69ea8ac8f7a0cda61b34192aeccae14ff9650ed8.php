<!-- 
<?php $__env->startSection('title', 'Inscription'); ?>
<?php $__env->startSection('link','/css/inscription.css'); ?>
<?php $__env->startSection('content'); ?>

   

<?php $__env->stopSection(); ?> -->
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romainlhuillier/Desktop/L2/second_semestre/Programation_web/TD/TM2/Exercice3/resources/views/inscription.blade.php ENDPATH**/ ?>