<?php $__env->startSection('content'); ?>
    <h1>$_POST('$name')</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/romainlhuillier/Desktop/L2/second_semestre/Programation_web/TD/TM2/Exercice3/resources/views/montest.blade.php ENDPATH**/ ?>