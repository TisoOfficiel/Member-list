<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TestController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route Racine et qui lance la function principal index
Route::get('/', [TestController::class,'index'])->name('home');

//Route par methode post qui permer de lancer la fonction CreationUtilisateur
Route::post('/inscriptionvalidation',[TestController::class,'CreationUtilisateur']);


// Route par methode post qui permet de lancer la fonction de ModificationUtilisateur
Route::post('/{id}/modification',[TestController::class,'ModificationUtilisateur'])->name('modifier');

// Route par methode post qui permet de lancer la fonction de SuppressionUtilisateur
Route::get('/{id}/supression',[TestController::class,'SuppressionUtilisateur'])->name('supprimer');


// get /noms - listener
// post /noms : creation personne
// put /noms/id : modification post /nom/id/modification
// delete /noms/id : suppression