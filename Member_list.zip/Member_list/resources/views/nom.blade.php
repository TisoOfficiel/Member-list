@extends('layout.app')
@section('title', 'Tableau de noms')
@section('linkcss','/css/main.css')
@section('content')

<section> 
<p class="messagePrevention">Pour éditer vous devez double cliquer normalement c'est intuitif mais au cas ou pour pas perdre de points</p>
<!-- Débutdu container Tableau , formulaire -->


<!-- Si erreur envoie formulaire on aggrandi la card conteneur pour le css -->

<!-- Entête du container -->
    @if($errors->any())
    <div class="listcontainer2" id="tableaContainer">
    @else
    <div class="listcontainer" id="tableaContainer">
    @endif
        <div class="contenttableau">
            <div class="lishead">
                <h2>Liste d'utilisateur</h2>
                <div class="headbutton">
                    <!-- Pour faire une recherche dans le tableau -->
                    <div class="btnAddSeach" >
                        <i class="material-icons">search</i>
                        <input type="text" id="myInput" onkeyup="seachkey()"class="search" placeholder="Nom Rechercher">
                    </div>
                    <!-- Pour afficher le formulaire d'ajout d'une personne -->
                    <div class="btnAddSeach" onclick="displayeadd()">
                        <i class="material-icons">add</i>
                        <header>Ajouter un utilisateur</header>
                    </div>
                
                </div>
            </div>
<!-- Fin entête container -->

<!-- Début tableau -->
            <div class="tabletest">
            <table class="tabletest2" id="myTable">
        
            @foreach ($personnes as $personne)

        <!-- Double click sur une ligne pour afficher le fomrulaire de modification  -->
                <tr class="list" ondblclick="addfunction('{{$personne->id}}','{{$personne->nom}}','{{$personne->prenom}}','{{$personne->age}}')">
                    <td > {{ $personne-> nom}}</td>
                    <td > {{ $personne->prenom }}</td>
                    <td class="age"> {{ $personne->age }}</td>
                    <td class="supp"><a onclick="if (!confirm('Êtes-vous sûr de supprimer {{$personne->nom}} {{$personne->prenom}}?')) { return false }" href="{{route('supprimer',["id"=>$personne->id])}}" ><i class="material-icons delete">delete</i></a></td>                   
                </tr>
            @endforeach

            </table>
            </div>
        </div>


    <!-- Si erreur envoie formulaire on affiche direct le formulaire dans la card -->
    @if($errors->any())
    <div class="form23" id="form22">
    @else
    <div class="form22" id="form22">
    @endif
        
    <!-- Savoir si on doit afficher le formulaire d'ajout ou non -->
    @if(session()->has('echecAjout'))
<!-- Fin tableau -->

<!-- Début Formulaire -->

<!-- Début Formulaire ajout -->
    <div class="addformulaire" id="addformulaire">
    @else
    <div class="addformulaire23" id="addformulaire">
    @endif

            <div class="headeraddform">
                <h2 class="title">Ajouter une personne</h2>
                <div class="close" onclick="closemodal()"><i class="material-icons ">close</i></div>
            </div>
            <form class="tabcontentform" action="/inscriptionvalidation" method="POST">
                @csrf
                <label for="nom">Nom</label>
                <input class="entrer" type="text"  id="nom" placeholder="Entrer votre nom" name="name" value="{{old('name')}}">
                <label for="prenom">Prénom</label>
                <input class="entrer" type="text"  id="prenom" placeholder="Entrer votre prénom" name="prenom" value="{{old('prenom')}}">
                <label for="age">Age</label>
                <input class="entrer" type="text"  id="age" placeholder="Entrer votre age" name="age" value="{{old('age')}}">
                
                <div class="btndiv">
                    <input type="submit" class="btn" value="Envoyer">
                </div>
            </form>
    </div>
<!-- Fin Formulaire ajout -->

<!-- Début Formulaire modification -->

    <!-- Savoir si on doit afficher le formulaire de modification ou non -->
    @if(session()->has('echecModif'))
        
    <div class="edituser" id="edituser">
    @else 

        <div class="edituser22" id="edituser">
    @endif 
            <div class="headeraddform">
                <h2 class="title">Modifier une personne</h2>
                <div class="close" onclick="closemodal()"><i class="material-icons ">close</i></div>
            </div>
            @if($errors->any())
            <form id="edisend"class="tabcontentform" action="/{{session()->get('UserId')}}/modification" method="POST"> 
            @endif
            <form id="edisend"class="tabcontentform" action="" method="POST">
                @csrf
                <label for="nom">Nom</label>
                <input class="entrer" type="text"  id="txt" placeholder="Entrer votre nom" name="nameNew" value="{{old('nameNew')}}">
                <label for="prenom">Prénom</label>
                <input class="entrer" type="text"  id="txt2" placeholder="Entrer votre prénom" name="prenomNew" value="{{old('prenomNew')}}">
                <label for="age">Age</label>
                <input class="entrer" type="text"  id="txt3" placeholder="Entrer votre age" name="ageNew" value="{{old('ageNew')}}">
            
               
                <div class="btndiv">
                    <input type="submit" class="btn" value="Modifier" id="editbtn" onclick="if (!confirm('Êtes-vous sûr de vouloir modifier cette personne ? ')) { return false }">                                                                      
                </div>
               
            </form>
        </div>
    </div>
</div>

<!-- Fin Formulaire ajout -->

<!-- Fin du container Tableau , formulaire -->


<!-- Début de notifications "message flash"  -->

    <!-- Si il y un ajout ou modif qui se fait alors on affiche la notif sinon non pour le css -->
    @if(session()->has('sucessAjout'))
    <div class="notification">
    @elseif(session()->has('sucessModification'))
    <div class="notification">
    @elseif(session()->has('sucessSuppression'))
    <div class="notification">
    @else
        <div class="notification2">
            @endif
   
        <div id="sucessNotif"class="alert alert-success">
            <span class="icon">
                <i class="material-icons">done</i>
            </span>
        
            <div class="text">
                <!-- Affichage du message d'ajout -->
                @if(session()->has('sucessAjout'))
                        <p>Succès {{session()->get('sucessAjout')}}</p>
                        <!-- Affichage du message de modification -->
                @elseif(session()->has('sucessModification'))
                        <p>Succès {{session()->get('sucessModification')}}</p>

                        <!-- Affichage du message de suppression -->
                @elseif(session()->has('sucessSuppression'))
                        <p>Succès {{session()->get('sucessSuppression')}}</p>
                @endif
                
                
            </div>
        
            <div class="closenotif" onclick="closenotif('sucess')"><i class="material-icons ">close</i></div>
        
        </div>
        </div>


         @if(session()->has('echecAjout'))
    <div class="notification">
                @elseif(session()->has('echecModif'))
                <div class="notification">
                    @else
                    <div class="notification2">
                @endif
        <div id="echecNotif" class="alert alert-warning">
            <span class="icon">
            <i class="material-icons">priority_high</i>
            </span>
        
            <div class="text">
                <!-- Affichage du message d'echec d'ajout avec errerurs -->
                @if(session()->has('echecAjout'))
                        <p>Echec {{session()->get('echecAjout')}}</p>
                        
                        @if($errors->any())
                            @foreach($errors->all() as $error)
                            <p>{{$error}}</p> 
                            @endforeach   
                        @endif
                
                        <!-- Affichage du message d'echec de modification avec errerurs -->       
                @elseif(session()->has('echecModif'))
                        <p>Echec {{session()->get('echecModif')}} </p>
                        @if($errors->any())
                        
                        @foreach($errors->all() as $error)
                        <p>{{$error}}</p> 
                        @endforeach   
                        @endif
                @endif
            </div>
        
            <div class="closenotif" onclick="closenotif('echec')"><i class="material-icons ">close</i></div>
        
        </div>
    </div>
 <!-- Fin de notifications "message flash"  -->
</section>

@section('linkjavascript',"{{URL::asset('/javascript/app.js')}}")